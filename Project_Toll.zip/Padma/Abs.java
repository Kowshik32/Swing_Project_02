public abstract class Abs extends Variable {
    @Override
    abstract void SingleCalulate();
}
